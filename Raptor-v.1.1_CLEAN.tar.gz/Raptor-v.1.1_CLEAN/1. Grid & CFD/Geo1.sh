#!/bin/bash
gmsh Test.geo -rand 1.e-14
