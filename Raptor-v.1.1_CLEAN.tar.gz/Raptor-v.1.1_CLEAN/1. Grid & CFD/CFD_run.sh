#!/bin/bash
SU2_CFD cfd_config_settings.cfg
