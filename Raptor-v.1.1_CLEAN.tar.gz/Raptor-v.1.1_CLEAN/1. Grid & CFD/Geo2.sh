#!/bin/bash

gmsh -2 Test.geo

