from wing_launch_config_opt import wing_launch_config_opt
from input_check_config_opt import input_check_config_opt

# ============================== INPUT DATA
# The length of each item must be the same and equal to the number of airfoils.
# Define chosen parametrization of each airfoil.
typ = ["NACA4"]

# Specify geometric parameters.
params = [[0, 0, 12]]

# Specify Trailing Edge type
TE = ['Y']

# Absolute angle of attack of each airfoil.
alpha = [10]

# Relative gap between TE and LE of each airfoil w.r.t. previous [x, y coordinates].
dist = [[0, 0]]

# Relative respective chord (%).
crel = [0.8]

# ============================== GRID DATA
# Grid: nodes' parameter.
nodes = 1

# Ellipse dimension.
ellipse_dimension = 0.85
ellipse_refining = 1

# Structured region
y_plus = 0.2
thick = 0.5
progr = 1.05
wall_refining = 1.25

Mach = 0.15
Re = 6e6
mu = 1.853e-05
temp = 288.15

# ============================== ADVANCED PARAMETERS
# Reference airfoil
# In case of multi-element configuration, define which is the airfoil to take as main reference for AOA, relative chord and grid features.
# If single-element configuration, insert 1. "DEFAULT" takes the airfoil with higher chord as reference.
ref_airfoil = "DEFAULT"

# Wake length and elements progression inside.
wake_length = 50
wake_progr = 1.3

# Meshing algorithm [an integer from 1 to 9 or 'DEFAULT', which corresponds to 5 (Delaunay)].
Mesh_Algo = 6

# Optional additional points, to help meshing algorithm (strictly depending on geometry and size).
# Note: almost necessary for Frontal-Delaunay (Mesh_Algo = 6); could avoid issues for Delaunay (Mesh_Algo = 5).
external_pts = 'YES'
# Circle dimension and elements' size (only if external_pts = 'YES')
# Dimension: value multiplied by greater ellipse's semi-axis. This product has a maximum of 200. Suggested: 15 - 25.
semicircle_dimension = 23
# Elements' size: value multiplied by minimum elements' size of the grid. Suggested: 200 - 300.
semicircle_elem_factor = 250




#=======================================================================================================================
# ========================================================================================================== CODE LAUNCH
# ================= Input debug
input_check(params, alpha, dist, crel, typ, TE, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil)

# ================= Geometry & grid generation
wing_launch(params, alpha, dist, crel, typ, TE, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil)

