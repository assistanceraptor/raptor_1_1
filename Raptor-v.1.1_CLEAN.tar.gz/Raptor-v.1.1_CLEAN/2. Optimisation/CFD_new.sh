#!/bin/bash
SU2_CFD ga_cfd.cfg


