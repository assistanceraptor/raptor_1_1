# ==================================================================================================================
# ------------- DIRECT, ADJOINT, AND LINEARIZED PROBLEM DEFINITION ------------#
# Specify turbulent model (NONE, SA, SA_NEG, SST)
KIND_TURB_MODEL_PREL = 'SA'

# Specify transition model (NONE, BC)
KIND_TRANS_MODEL_PREL = 'NONE'

FREESTREAM_TURBULENCEINTENSITY_PREL = '0.0015'

# Restart solution (NO, YES)
RESTART_SOL_PREL = 'NO'

# -------------------- COMPRESSIBLE FREE-STREAM DEFINITION --------------------#
# Side-slip angle (degrees, only for compressible flows)
SIDESLIP_ANGLE_PREL = '0.0'

# Reynolds length (1 m by default)
REYNOLDS_LENGTH_PREL = '1'
#REYNOLDS_LENGTH = '1.3'

# ---- IDEAL GAS, POLYTROPIC, VAN DER WAALS AND PENG ROBINSON CONSTANTS -------#
# Different gas model (STANDARD_AIR, IDEAL_GAS, VW_GAS, PR_GAS)
FLUID_MODEL_PREL = 'STANDARD_AIR'

# Specific gas constant (287.058 J/kg*K default and this value is hardcoded
#                        for the model STANDARD_AIR, compressible only)
GAS_CONSTANT_PREL = '287.058'

# Ratio of specific heats (1.4 default and the value is hardcoded
#                          for the model STANDARD_AIR, compressible only)
GAMMA_VALUE_PREL = '1.4'

# --------------------------- VISCOSITY MODEL ---------------------------------#
# Viscosity model (SUTHERLAND, CONSTANT_VISCOSITY).
VISCOSITY_MODEL_PREL = 'CONSTANT_VISCOSITY'

# Sutherland Temperature Ref (273.15 K default value for AIR SI)
# (only for VISCOSITY_MODEL = SUTHERLAND)
MU_T_REF_PREL = '273.15'

# Sutherland constant (110.4 default value for AIR SI)
# (only for VISCOSITY_MODEL = SUTHERLAND)
SUTHERLAND_CONSTANT_PREL = '110.4'

# --------------------------- THERMAL CONDUCTIVITY MODEL ----------------------#
# Conductivity model (CONSTANT_CONDUCTIVITY, CONSTANT_PRANDTL).
CONDUCTIVITY_MODEL_PREL = 'CONSTANT_PRANDTL'
#
# Laminar Prandtl number (0.72 (air), only for CONSTANT_PRANDTL)
PRANDTL_LAM_PREL = 0.72
#
# Turbulent Prandtl number (0.9 (air), only for CONSTANT_PRANDTL)
PRANDTL_TURB_PREL = 0.90

# ---------------------- REFERENCE VALUE DEFINITION ---------------------------#
# Reference origin for moment computation
REF_ORIGIN_MOMENT_X_PREL = '0.25'
REF_ORIGIN_MOMENT_Y_PREL = '0.00'
REF_ORIGIN_MOMENT_Z_PREL = '0.00'
#
# Reference length for pitching, rolling, and yawing non-dimensional moment
REF_LENGTH_PREL = '1.0'

# Reference area for force coefficients (0 implies automatic calculation)
REF_AREA_PREL = '0'

# ------------- COMMON PARAMETERS DEFINING THE NUMERICAL METHOD ---------------#
# Courant-Friedrichs-Lewy condition of the finest grid
CFL_NUMBER_PREL = '1000.0'

# Adaptive CFL number (NO, YES)
CFL_ADAPT_PREL = 'NO'

# Parameters of the adaptive CFL number (factor down, factor up, CFL min value,
#                                        CFL max value )
CFL_ADAPT_PARAM_PREL = '( 0.999, 100 , 100.0, 1e5 )'

# Number of total iterations
ITER_PREL = '3000'

# -------------------- FLOW NUMERICAL METHOD DEFINITION -----------------------#
# Convective numerical method (JST, LAX-FRIEDRICH, CUSP, ROE, AUSM, HLLC,
#                              TURKEL_PREC, MSW)
CONV_NUM_METHOD_FLOW_PREL = 'JST'

# Monotonic Upwind Scheme for Conservation Laws (TVD) in the flow equations.
#           Required for 2nd order upwind schemes (NO, YES)
MUSCL_FLOW_PREL = 'YES'

# Slope limiter (VENKATAKRISHNAN, MINMOD)
SLOPE_LIMITER_FLOW_PREL = 'VENKATAKRISHNAN'

# Coefficient for the Venkat's limiter (upwind scheme). A larger values decrease
#             the extent of limiting, values approaching zero cause
#             lower-order approximation to the solution (0.05 by default)
VENKAT_LIMITER_COEFF_PREL = '0.05'

# 2nd and 4th order artificial dissipation coefficients for JST method ( 0.5, 0.02 by default )
JST_SENSOR_COEFF_PREL = '( 0.5, 0.02 )'

# --------------------------- CONVERGENCE PARAMETERS --------------------------#
# Convergence criteria (CAUCHY, RESIDUAL)
CONV_FIELD_PREL = '(LIFT, RMS_DENSITY)'
#
# Min value of the residual (log10 of the residual)
CONV_RESIDUAL_MINVAL_PREL = '-4'
#
# Start convergence criteria at iteration number
CONV_STARTITER_PREL = '2000'
#
# Number of elements to apply the criteria
CONV_CAUCHY_ELEMS_PREL = '200'
#
# Epsilon to control the series convergence
CONV_CAUCHY_EPS_PREL = '1e-4'

# ------------------------- INPUT/OUTPUT INFORMATION --------------------------#
# Screen output fields
SCREEN_OUTPUT_PREL = '(INNER_ITER, WALL_TIME, RMS_DENSITY, RMS_NU_TILDE, LIFT, DRAG, AVG_CFL)'

# History output groups
HISTORY_OUTPUT_PREL = '(ITER, WALL_TIME, RMS_RES, AERO_COEFF, CAUCHY)'

# Files to output
# Possible formats : (TECPLOT, TECPLOT_BINARY, SURFACE_TECPLOT,
#  SURFACE_TECPLOT_BINARY, CSV, SURFACE_CSV, PARAVIEW, PARAVIEW_BINARY, SURFACE_PARAVIEW,
#  SURFACE_PARAVIEW_BINARY, MESH, RESTART_BINARY, RESTART_ASCII, CGNS, STL)
# default : (RESTART, PARAVIEW, SURFACE_PARAVIEW)
OUTPUT_FILES_PREL = '(RESTART, PARAVIEW, SURFACE_PARAVIEW, SURFACE_CSV)'

# Output file format (PARAVIEW, TECPLOT, STL)
TABULAR_FORMAT_PREL = 'CSV'

# Writing frequency for screen output
SCREEN_WRT_FREQ_INNER_PREL = '50'

# Writing frequency for volume/surface output
OUTPUT_WRT_FREQ_PREL = '100'
