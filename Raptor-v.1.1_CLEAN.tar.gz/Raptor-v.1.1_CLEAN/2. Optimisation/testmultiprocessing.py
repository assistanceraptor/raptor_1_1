import multiprocessing
import time

n = 10
start = time.perf_counter()


def do_something(seconds):
    print(f'Sleeping {seconds} seconds(s)..')
    time.sleep(seconds)
    print('Done Sleeping..')

process = []

h = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
for i in range(n):
    p = multiprocessing.Process(target=do_something, args=[h[i]])
    p.start()
    process.append(p)

for process in process:
    process.join()

finish = time.perf_counter()

print(f'Finished in {round(finish-start, 2)} seconds(s)')