# PARAMETRIC GENERATION OF WINGS
from multiGeometry import multiGeometry
from mesh_gen import mesh_gen_VISCOUS
from mesh_gen import mesh_gen_EULER
from wall_spacing import wall_spacing
import subprocess
import time
import math as mt


# Script General info
def wing_launch_opt(flow, n, params, alpha, dist, crel, typ, TE, Re, mu, nodes, y_plus, thick, progr, temp,
                    ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension,
                    semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, farfield_size):
    print('Creating airfoils geometry...')
    start = time.process_time()

    nairfoils = len(typ)
    # param_ : n. of parameters required by IGP parametrization

    # Importing airfoils respective coordinates
    x, y, index_Above1, index_Below1, index_Above2, index_Below2, TE_len, ref_airfoil = multiGeometry(nairfoils, n,
                                                                                                      params, alpha,
                                                                                                      dist, crel, typ,
                                                                                                      TE, ref_airfoil)

    print('Creating airfoils grid...')

    if flow == 'VISCOUS':
        # Boundary Layer - structured region definition
        BL_thickness, norm_nodes, s, progr, Rex, norm_nodes_TE, U, rho = wall_spacing(Re, crel, mu, nairfoils, y_plus,
                                                                                      progr, thick,
                                                                                      temp, TE, Mach)
    else:
        U = Mach * mt.sqrt(1.4 * 287 * temp)
        nu = U / Re
        rho = mu / nu

    # Nodes parameters
    nodes = float(nodes)

    h = 0.001 / nodes  # wake

    airfoil_nodes = [None] * nairfoils

    for i in range(0, len(airfoil_nodes)):
        prop_list_a = [550 * wall_refining[i], 250 * wall_refining[i], 250 * wall_refining[i], 300 * wall_refining[i],
                       300 * wall_refining[i]]  # [800, 350, 350, 420, 420]  airfoil
        airfoil_nodes[i] = [element_a * nodes for element_a in prop_list_a]

    prop_list_e = [2.25 * ellipse_refining, 4.5 * ellipse_refining]  # ellipse
    ellipse_nodes = [element_e * nodes for element_e in prop_list_e]

    if flow == 'EULER':
        mesh_gen_EULER(x, y, nairfoils, index_Above1, index_Below1, index_Above2, index_Below2, alpha, dist, crel, TE,
                       airfoil_nodes, ellipse_nodes, h, nodes, TE_len, ellipse_dimension, Mesh_Algo, external_pts,
                       wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, ref_airfoil,
                       farfield_size)
    else:
        mesh_gen_VISCOUS(x, y, nairfoils, index_Above1, index_Below1, index_Above2, index_Below2, alpha, dist, crel, TE,
                         BL_thickness, norm_nodes, s, progr, airfoil_nodes, ellipse_nodes, h, nodes, norm_nodes_TE,
                         TE_len,
                         ellipse_dimension, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension,
                         semicircle_elem_factor, ref_airfoil, farfield_size)

    # data_id = open('Flow_data.txt', 'w+')
    # data_id.write(
    # 'Number of airfoils: %d.\nFree-stream Mach: %.5f.\nReynolds number: %.5f.\nReference AOA: %.3f.\nReference temperature: %.2f.\nReference dynamic viscosity: %.6f.\n' % (
    # nairfoils, Mach, Re, alpha[0], temp, mu))
    # data_id.close()

    print('Free-stream velocity is: %.3f m/s.' % U)
    SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")
    rho_udm = ('kg/m3').translate(SUP)
    print('Free-stream density is: %.6f ' % rho + rho_udm + '.\n')

    # print('Check the text file "Flow_data.txt" for your input flow data.\n\n')

    print('Geometry and grid completed! (%.3f s)\n' % (time.process_time() - start))

    # print("NOTES BEFORE CONTINUING\nOnce the .geo file has been opened, to export your .su2 file open the window 'File -> Export' and and select your desired folder.\n")
    # input("[ Press ENTER to continue and open .geo file on GMSH]\n")
    # subprocess.Popen("./Geo1.sh")

    subprocess.call("./Geo2.sh")
    print("File .su2 created!\n ")

    return []
