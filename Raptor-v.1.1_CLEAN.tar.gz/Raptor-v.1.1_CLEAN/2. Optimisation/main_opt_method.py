def main_PSO_algo_params():
    swarmsize = 5
    omega = 0.5
    phip = 0.5
    phig = 0.5
    maxiter = 25
    minstep = 1e-5
    minfunc = 1e-5
    debug = False
    processes = 1
    particle_output = False
    #timeout = 1e10

    return swarmsize, omega, phip, phig, maxiter, minstep, minfunc, debug, processes, particle_output



def main_STEEPEST_algo_params():
    S0 = 0.005
    SMAX = 0.0025
    #REF_SIZE = 0.06
    REF_SIZE = 0.005

    min_iter = 5
    max_iter = 15
    max_stall_iterations = 5
    tolerance = 0.03
    debug = False
    noise = 0.017

    processes = 4

    return S0, SMAX, REF_SIZE, min_iter, max_iter, max_stall_iterations, tolerance, debug, noise, processes
