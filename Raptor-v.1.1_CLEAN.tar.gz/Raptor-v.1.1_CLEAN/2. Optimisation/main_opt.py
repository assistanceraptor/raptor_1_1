# ============================== INPUT DATA
# The length of each item must be the same and equal to the number of airfoils.

# Objective function
objective_function = ['MAX', 'LIFT']

flow = 'VISCOUS'

# Define chosen parametrization of each airfoil.
typ = ["MY_FILE_1", "MY_FILE_2"]

# Specify Trailing Edge type
TE = ['N', 'Y']


# ====================== Starting configuration
# Specify geometric parameters
start_alpha = [7.7, 37.7]

# Relative gap between TE and LE of each airfoil w.r.t. previous [x, y coordinates]
start_dist = [[0, 0], [0.0, -0.025]]

# Relative respective chord (%).
start_crel = [1, 0.3]

# Specify geometric parameters.
start_params = [['MY_FILE_1'], ['MY_FILE_2']]


# ====================== Preliminary study
# Note: preliminary studies will provide ideal bounds and proper starting point based on other methods.
preliminary = 'YES'
preliminary_method = ['EULER', 'LHS']

# ====================== Optimisation
# Optimization Method
optim_method = 'STEEPEST'

# Design Variables and bounds
design_variables_alpha = ['N', 'N']
design_variables_dist = [['Y', 'Y']]
design_variables_crel = ['N']
design_variables_params = [['N', 'N', 'N', 'N', 'N', 'N', 'N', 'N'], ['N', 'N', 'N', 'N', 'N', 'N', 'N', 'N']]

# The following bounds will be used directly by optimization algorithm if preliminary = 'NO'.
# Otherwise (preliminary = 'YES'), these bounds will apply to preliminary algorithm selected. Preliminary algorithm will find new bounds based on obtained results.
bounds_alpha = [[0, 12], [20, 50]]  # if you insert limit values of params which have been constrained ('N'), they will be ignored.
bounds_dist = [[[-0.025, 0.025], [-0.05, -0.0105]]]
bounds_crel = [[0.1, 0.4]]
bounds_params = [[[0.25, 0.85], [0.15, 0.75], [-0.025, 0.2], [0.0, 0.175], [0.25, 0.39], [0.03, 0.3], [0.5, 1.3], [1.0, 4.8]], [[0.25, 0.85], [0.15, 0.75], [-0.025, 0.2], [0.0, 0.175], [0.25, 0.39], [0.03, 0.3], [0.5, 1.3], [1.0, 4.8]]]

# ============================== GRID DATA
farfield_size = 300
# Grid: nodes' parameter.
nodes = 0.3

# Ellipse dimension.
ellipse_dimension = 0.85
ellipse_refining = 0.3

# Structured region
y_plus = [0.08, 0.12]
thick = [0.15, 0.25]
progr = [1.15, 1.15]
wall_refining = [0.3, 0.3]

# Free-stream features
Mach = 0.21
Re = 2.2e6
mu = 1.853e-05
temp = 287.15


# ============================== ADVANCED PARAMETERS
n = 320

limit_exclusions = ['YES', 0]
iter_range = 200
dev_std = 0.005

# Reference airfoil
# In case of multi-element configuration, define which is the airfoil to take as main reference for AOA, relative chord and grid features.
# If single-element configuration, insert 1. "DEFAULT" takes the airfoil with higher chord as reference.
ref_airfoil = "DEFAULT"

# Wake length and elements progression inside.
wake_length = 50
wake_progr = 1.3

# Meshing algorithm [an integer from 1 to 9 or 'DEFAULT', which corresponds to 5 (Delaunay)].
Mesh_Algo = 6

# Optional additional points, to help meshing algorithm (strictly depending on geometry and size).
# Note: almost necessary for Frontal-Delaunay (Mesh_Algo = 6); could avoid issues for Delaunay (Mesh_Algo = 5).
external_pts = 'YES'
# Circle dimension and elements' size (only if external_pts = 'YES')
# Dimension: value multiplied by greater ellipse's semi-axis. This product has a maximum of 200. Suggested: 15 - 25.
semicircle_dimension = 18
# Elements' size: value multiplied by minimum elements' size of the grid. Suggested: 200 - 300.
semicircle_elem_factor = 250
