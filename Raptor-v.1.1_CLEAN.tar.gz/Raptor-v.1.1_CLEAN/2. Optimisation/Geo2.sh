#!/bin/bash

gmsh -2 Test.geo -rand 1.e-14

