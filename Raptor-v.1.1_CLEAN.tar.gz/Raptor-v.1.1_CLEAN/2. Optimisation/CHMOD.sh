#!/bin/bash

chmod +x /MatlabScripts-config_opt/HS_Matlab.sh
chmod +x Geo1.sh
chmod +x Geo2.sh
chmod +x CFD_run.sh
chmod +x CFD_new.sh

