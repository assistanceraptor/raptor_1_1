global mp_pool
import subprocess
import numpy as np
from wing_launch_opt import wing_launch_opt
from main_opt_method import main_STEEPEST_algo_params
from lift_driver_mode import *
from lift_driver_mode_preliminary import *
import math as mt
import os
import shutil
import sys
import multiprocessing as mp
import pandas as pd
import random
from scipy import linalg
from cfg_printing import cfg_printing
from main_configuration_file import *
from main_configuration_file_preliminary import *


def obj_evaluation_STEEPEST(objective_function, limit_exclusions, ITER, iter_range, dev_std, typology, step, i):
    if objective_function[1] == 'LIFT':
        column_name = '       "CL"       '
    elif objective_function[1] == 'DRAG':
        column_name = '       "CD"       '
    else:
        column_name = '      "CEff"      '

    if typology == 'centroid':
        os.chdir('./STEP_%d/Centroid_%d' % (step, step))
    else:
        os.chdir('./STEP_%d/Process_%d' % (step, i))

    try:
        df = pd.read_csv("history.csv")
        fx_old = df.at[(df.index.stop - 1), column_name]
        sim_iter = df.index.stop - 1
        if sim_iter <= iter_range:
            iter_range = sim_iter - 1
        sum_mean = 0
        for i in range(sim_iter - iter_range, sim_iter):
            sum_mean = sum_mean + df.at[i, column_name]
        mean_obj = sum_mean / iter_range

        sum_dev_std = 0
        for i in range(sim_iter - iter_range, sim_iter):
            sum_dev_std = sum_dev_std + ((df.at[i, column_name] - mean_obj) ** 2)
        sigma = mt.sqrt(sum_dev_std / iter_range)

    except:
        fx_old = 0

    if objective_function[0] == 'MAX':
        fx = fx_old
        if limit_exclusions[0] == 'YES' and sigma > dev_std:
            fx = mean_obj * limit_exclusions[1]
    else:
        fx = -fx_old
        if limit_exclusions[0] == 'YES' and sigma > dev_std:
            fx = -mean_obj * limit_exclusions[1]
        pass


    path_parent = os.path.dirname(os.path.dirname(os.getcwd()))
    os.chdir(path_parent)

    return fx


def vector_X(var, ref_size, h, lb, ub):
    i = 0

    while i <= (len(var) - 1):
        if i == 0:
            x = [[var[0] - ref_size / 2], [var[0] + ref_size / 2]]
        elif i == 1:
            x = [[var[0] - ref_size / 2, var[1] - h / 3], [var[0] + ref_size / 2, var[1] - h / 3],
                 [var[0], var[1] + h * 2 / 3]]
        elif i == 2:
            x = [[var[0] - ref_size / 2, var[1] - h / 3, var[2] - h / 3], [var[0] + ref_size / 2, var[1] - h / 3, var[2] - h / 3],
                 [var[0], var[1] + h * 2 / 3, var[2]], [var[0], var[1] - h / 3, var[2] + 2 * h / 3]]
        else:
            for k in range(0, len(x)):
                if k < len(x) - 1:
                    x[k].append(var[i] - h / 3)
                else:
                    x[k].append(var[i])
            x.append([None] * len(x[i]))
            for j in range(0, len(x[i])):
                if j == 0:
                    x[i + 1][j] = var[j]
                elif j == len(x[i]) - 1:
                    x[i + 1][j] = var[j] + 2 * h / 3
                else:
                    x[i + 1][j] = var[j] - h / 3
        i = i + 1

    # Check limits (varbound)
    count0 = 0
    count1 = 0
    for j in range(0, len(x)):
        for k in range(0, len(x[j])):
            if x[j][k] <= lb[k] and count0 == 0:
                x[j][k] = lb[k]
                count0 = 1
            elif x[j][k] <= lb[k] and count0 == 1:
                x[j][k] = lb[k] + (random.uniform(0.01, 0.05)) * abs(lb[k])
            elif x[j][k] >= ub[k] and count1 == 0:
                x[j][k] = ub[k]
                count1 = 1
            elif x[j][k] >= ub[k] and count1 == 1:
                x[j][k] = ub[k] - (random.uniform(0.01, 0.05)) * abs(ub[k])
            else:
                pass

    return x


# def _cons_ieqcons_wrapper(ieqcons, args, kwargs, x):
#     return np.array([y(x, *args, **kwargs) for y in ieqcons])
#
#
# def _cons_f_ieqcons_wrapper(f_ieqcons, args, kwargs, x):
#     return np.array(f_ieqcons(x, *args, **kwargs))


def steepest(func, lb, ub, ieqcons=[], f_ieqcons=None, args=(), kwargs={}, S0=0.07, SMAX=0.05, REF_SIZE=0.06,
             min_iter=5, max_iter=25, max_stall_iterations=5, tolerance=0.01, debug=False, noise=0.017, processes=1):
    """
    Perform a Steepest Ascent Optimization

    Parameters
    ==========
    func : function
        The function to be minimized
    lb : array
        The lower bounds of the design variable(s)
    ub : array
        The upper bounds of the design variable(s)

    Returns
    =======
    g : array
        The swarm's best known position (optimal design)
    f : scalar
        The objective value at ``g``
    p : array
        The best known position per particle
    pf: arrray
        The objective values at each position in p

    """

    assert len(lb) == len(ub), 'Lower- and upper-bounds must be the same length'
    assert hasattr(func, '__call__'), 'Invalid function handle'
    lb = np.array(lb)
    ub = np.array(ub)
    assert np.all(ub > lb), 'All upper-bound values must be greater than lower-bound values'

    # Initialize the multiprocessing module if necessary
    # if processes > 1:
    #     import multiprocessing
    #     mp_pool = multiprocessing.Pool(processes)

    # Initialize the steepest ascent ############################################
    H = mt.sqrt(3) / 2 * REF_SIZE
    flow, n, objective_function, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, bounds_alpha, bounds_dist, bounds_crel, bounds_params, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, dev_std, iter_range, farfield_size, varbound, preliminary_method = args
    M = 0.5

    # =========================================================================================================== STEP 0
    step = 0
    nairfoils = len(typ)

    VAR = [['KIND_TURB_MODEL', KIND_TURB_MODEL], ['KIND_TRANS_MODEL', KIND_TRANS_MODEL],
           ['FREESTREAM_TURBULENCEINTENSITY', FREESTREAM_TURBULENCEINTENSITY], ['RESTART_SOL', RESTART_SOL],
           ['MACH_NUMBER', Mach], ['AOA', start_alpha[0]], ['SIDESLIP_ANGLE', SIDESLIP_ANGLE],
           ['FREESTREAM_TEMPERATURE', temp], ['GAS_CONSTANT', GAS_CONSTANT],
           ['FLUID_MODEL', FLUID_MODEL], ['GAMMA_VALUE', GAMMA_VALUE], ['REYNOLDS_NUMBER', Re],
           ['REYNOLDS_LENGTH', REYNOLDS_LENGTH], ['VISCOSITY_MODEL', VISCOSITY_MODEL], ['MU_CONSTANT',  mu],
           ['MU_T_REF', MU_T_REF], ['SUTHERLAND_CONSTANT', SUTHERLAND_CONSTANT],
           ['CONDUCTIVITY_MODEL', CONDUCTIVITY_MODEL], ['PRANDTL_LAM', PRANDTL_LAM], ['PRANDTL_TURB', PRANDTL_TURB],
           ['REF_ORIGIN_MOMENT_X', REF_ORIGIN_MOMENT_X], ['REF_ORIGIN_MOMENT_Y', REF_ORIGIN_MOMENT_Y],
           ['REF_ORIGIN_MOMENT_Z', REF_ORIGIN_MOMENT_Z], ['REF_LENGTH', REF_LENGTH], ['REF_AREA', REF_AREA],
           ['CFL_NUMBER', CFL_NUMBER], ['CFL_ADAPT', CFL_ADAPT], ['CFL_ADAPT_PARAM', CFL_ADAPT_PARAM], ['ITER', ITER],
           ['CONV_NUM_METHOD_FLOW', CONV_NUM_METHOD_FLOW], ['MUSCL_FLOW', MUSCL_FLOW],
           ['SLOPE_LIMITER_FLOW', SLOPE_LIMITER_FLOW], ['VENKAT_LIMITER_COEFF', VENKAT_LIMITER_COEFF],
           ['JST_SENSOR_COEFF', JST_SENSOR_COEFF], ['CONV_FIELD', CONV_FIELD],
           ['CONV_RESIDUAL_MINVAL', CONV_RESIDUAL_MINVAL], ['CONV_STARTITER', CONV_STARTITER],
           ['CONV_CAUCHY_ELEMS', CONV_CAUCHY_ELEMS], ['CONV_CAUCHY_EPS', CONV_CAUCHY_EPS],
           ['MESH_FILENAME', 'Test.su2'], ['SCREEN_OUTPUT', SCREEN_OUTPUT], ['HISTORY_OUTPUT', HISTORY_OUTPUT],
           ['OUTPUT_FILES', OUTPUT_FILES], ['TABULAR_FORMAT', TABULAR_FORMAT],
           ['SCREEN_WRT_FREQ_INNER', SCREEN_WRT_FREQ_INNER], ['OUTPUT_WRT_FREQ', OUTPUT_WRT_FREQ]]
    VAR2 = [['FIXED_CL_MODE', FIXED_CL_MODE], ['TARGET_CL', TARGET_CL], ['DCL_DALPHA', DCL_DALPHA],
            ['UPDATE_AOA_ITER_LIMIT', UPDATE_AOA_ITER_LIMIT], ['ITER_DCL_DALPHA', ITER_DCL_DALPHA],
            ['EVAL_DOF_DCX', EVAL_DOF_DCX]]

    cfg_printing(nairfoils, VAR, VAR2, flow) #, step)

    print('Step 0.\n')

    data_id = open('HistorySTEEPEST.txt', 'w+')
    data_id.write('-- STEEPEST OPTIMISATION --\n')
    if objective_function[0] == 'MIN':
        data_id.write('Minimisation optimisation.\n')
    else:
        data_id.write('Maximisation optimisation.\n')
    data_id.close()
    opt = []
    var = []

    # Design variables
    for i in range(0, len(design_variables_alpha)):
        if design_variables_alpha[i] == 'Y':
            var.append(start_alpha[i])
    for i in range(0, len(design_variables_dist)):
        for j in range(0, len(design_variables_dist[i])):
            if design_variables_dist[i][j] == 'Y':
                var.append(start_dist[i + 1][j])
    for i in range(0, len(design_variables_crel)):
        if design_variables_crel[i] == 'Y':
            var.append(start_crel[i + 1][j])
    for i in range(0, len(design_variables_params)):
        for j in range(0, len(design_variables_params[i])):
            if design_variables_params[i][j] == 'Y':
                var.append(start_params[i][j])

    Y = [var]

    S = [S0]

    ref_size = REF_SIZE
    h = H
    # Matrix of experiments for step 0
    x = vector_X(var, ref_size, h, lb, ub)
    x_centr = Y[step]
    data_id = open('HistorySTEEPEST.txt', 'a')
    data_id.write('Design variables of new candidates (' + str(step) + ').\n')
    for i in range(0, len(x)):
        for j in range(0, len(x[i])):
            if j == 0:
                data_id.write('[%.8f, ' % x[i][j])
            elif j != 0 and j < len(x[i]) - 1:
                data_id.write('%.8f, ' % x[i][j])
            else:
                data_id.write('%.8f].\n' % x[i][j])
    data_id.close()

    # Calculate objective and extract it from csv file
    PROC = []

    if processes > 1:
        if processes > len(x) + 1:
            processes = len(x) + 1
            data_id = open('HistorySTEEPEST.txt', 'a')
            data_id.write('Invalid definition for number of processes: maximum number is equal to [(n° of design variables) + 1].\nAs consequence, number of processes is reduced to %d.\n' % processes)
            data_id.close()
        i = 0

        while i <= len(x):
            j = 0
            centroid = 0
            p = mp.Process(target=obj_steepest, args=(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method))
            PROC.append(p)
            p.start()
            for j in range(i, min(processes + 1, len(x))):
                centroid = 1
                p = mp.Process(target=obj_steepest, args=(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method))
                PROC.append(p)
                p.start()
            for proc in PROC:
                proc.join()

            i = i + processes

    else:
        j = 0
        centroid = 0
        obj_steepest(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method)
        for j in range(0, len(x)):
            centroid = 1
            obj_steepest(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method)


    new_opt = obj_evaluation_STEEPEST(objective_function, limit_exclusions, ITER, iter_range, dev_std, 'centroid', step, 0)
    opt.append(new_opt)
    data_id = open('HistorySTEEPEST.txt', 'a')
    data_id.write('New Optimum Fitness (Centroid of step ' + str(step) + '): %.8f.\n' % opt[step])
    data_id.close()

    fx_new = np.zeros(len(x))
    for i in range(0, len(x)):
        fx_new[i] = obj_evaluation_STEEPEST(objective_function, limit_exclusions, ITER, iter_range, dev_std, 'process', step, i)
        data_id = open('HistorySTEEPEST.txt', 'a')
        data_id.write('Step n°' + str(step) + ', process ' + str(i) + ' Fitness: %.8f.\n' % fx_new[i])
        data_id.close()

    fx = [fx_new]
    A = [None] * len(x)
    for i in range(0, len(x)):
        A[i] = [None] * (len(x[i]) + 1)
        for j in range(0, len(x[i]) + 1):
            if j == 0:
                A[i][j] = 1
            else:
                A[i][j] = x[i][j - 1]

    coeff = np.concatenate(
        linalg.solve(A, np.matrix(fx_new).T))  # [source](inv(np.matrix(A)) * np.matrix([obj_new]).T).tolist()

    new_gradmag = 0
    for i in range(1, len(coeff)):
        new_gradmag = new_gradmag + coeff[i] ** 2
    gradmag = [mt.sqrt(new_gradmag)]

    if any(y > (opt[step] + tolerance) for y in fx_new):      # Can proceed and move to new centroid
        check = 0
        gradmag = [mt.sqrt(new_gradmag)]
        data_id = open('HistorySTEEPEST.txt', 'a')
        data_id.write('Vector of coefficients:')
        for i in range(0, len(coeff)):
            if i < len(coeff) - 1:
                data_id.write(' %.8f,' % coeff[i])
            else:
                data_id.write(' %.8f\n' % coeff[i])
        data_id.write('gradmag: %.8f.\n' % gradmag[step])
        data_id.close()
        new_var = []
        print(varbound)
        for i in range(0, len(var)):
            new_dv = Y[step][i] + S0 * coeff[i + 1] / gradmag[step]
            # Check limits (varbound) for new optimal design variables

            print(new_dv)
            if new_dv <= varbound[i][0]:
                new_dv = varbound[i][0]
            elif new_dv >= varbound[i][1]:
                new_dv = varbound[i][1]
            else:
                pass
                print(new_dv)
            new_var.append(new_dv)
        Y.append(new_var)
        counter = 0

    else:
        check = 1
        Y.append(var)
        counter = 1

    # =========================================================================================================== MAIN LOOP
    # MAIN LOOP
    print('Main Loop starts')
    while (step <= max_iter and counter <= max_stall_iterations) or step < min_iter:
        step = step + 1
        data_id = open('HistorySTEEPEST.txt', 'a')
        print('New step ' + str(step) + '.\n')
        data_id.write('\nSTEP N°' + str(step) + '.\n')
        data_id.write('New design variables values found (Centroid of step ' + str(step) + '): ')
        for i in range(0, len(var)):
            if i < len(var) - 1:
                data_id.write('%.8f, ' % Y[step][i])
            else:
                data_id.write('%.8f.\n' % Y[step][i])
        data_id.close()

        # Design variables
        var = []
        s = 0
        for i in range(0, len(design_variables_alpha)):
            if design_variables_alpha[i] == 'Y':
                var.append(Y[step][s])
                s = s + 1
        for i in range(0, len(design_variables_dist)):
            for j in range(0, len(design_variables_dist[i])):
                if design_variables_dist[i][j] == 'Y':
                    var.append(Y[step][s])
                    s = s + 1

        if check == 0:
            ref_size = REF_SIZE
            h = H
        elif check == 1:
            ref_size = REF_SIZE * 2
            h = H * 2
        elif check == 2:
            ref_size = REF_SIZE / 2
            h = H / 2
        else:
            ref_size = ref_size / 2
            h = h / 2

        x = vector_X(var, ref_size, h, lb, ub)
        x_centr = Y[step]
        data_id = open('HistorySTEEPEST.txt', 'a')
        data_id.write('Design variables of new candidates (' + str(step) + ').\n')
        for i in range(0, len(x)):
            for j in range(0, len(x[i])):
                if j == 0:
                    data_id.write('[%.8f, ' % x[i][j])
                elif j != 0 and j < len(x[i]) - 1:
                    data_id.write('%.8f, ' % x[i][j])
                else:
                    data_id.write('%.8f].\n' % x[i][j])
        data_id.close()

        # Calculate objective and extract it from csv file
        PROC = []

        if processes > 1:
            if processes > len(x) + 1:
                processes = len(x) + 1
                data_id = open('HistorySTEEPEST.txt', 'a')
                data_id.write(
                    'Invalid definition for number of processes: maximum number is equal to [(n° of design variables) + 1].\nAs consequence, number of processes is reduced to %d.\n' % processes)
                data_id.close()
            i = 0
            while i <= len(x):
                if check == 0:
                    j = 0
                    centroid = 0
                    p = mp.Process(target=obj_steepest, args=(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method))
                    PROC.append(p)
                    p.start()
                for j in range(i, min(processes + i, len(x))):
                    centroid = 1
                    p = mp.Process(target=obj_steepest, args=(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method))
                    PROC.append(p)
                    p.start()
                for proc in PROC:
                    proc.join()

                i = i + processes

        else:
            j = 0
            centroid = 0
            obj_steepest(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method)
            for j in range(0, len(x)):
                centroid = 1
                obj_steepest(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method)

        if check == 0:

            new_opt = obj_evaluation_STEEPEST(objective_function, limit_exclusions, ITER, iter_range, dev_std, 'centroid', step, 0)
            opt.append(new_opt)
        else:
            new_opt = opt[step - 1]
            opt.append(new_opt)

        data_id = open('HistorySTEEPEST.txt', 'a')
        data_id.write('New Optimum Fitness (Centroid of step ' + str(step) + '): %.8f.\n' % opt[step])
        data_id.write('Counter: %d.\n' % counter)
        fx_new = np.zeros(len(x))
        for i in range(0, len(x)):

            fx_new[i] = obj_evaluation_STEEPEST(objective_function, limit_exclusions, ITER, iter_range, dev_std, 'process', step, i)
            data_id = open('HistorySTEEPEST.txt', 'a')
            data_id.write('Step n°' + str(step) + ', process ' + str(i) + ' Fitness: %.8f.\n' % fx_new[i])
            data_id.close()
        fx.append([fx_new])
        data_id.close()

        if any(y > opt[step] for y in fx_new):  # Can proceed and move to new centroid
            check = 0
            A = [None] * len(x)
            for i in range(0, len(x)):
                A[i] = [None] * (len(x[i]) + 1)
                for j in range(0, len(x[i]) + 1):
                    if j == 0:
                        A[i][j] = 1
                    else:
                        A[i][j] = x[i][j - 1]

            coeff = np.concatenate(linalg.solve(np.array(A), np.matrix(fx_new).T))  # [source](inv(np.matrix(A)) * np.matrix([obj_new]).T).tolist()
            new_gradmag = 0
            for i in range(1, len(coeff)):
                new_gradmag = new_gradmag + coeff[i] ** 2
            new_gradmag = mt.sqrt(new_gradmag)
            gradmag.append(new_gradmag)

            data_id = open('HistorySTEEPEST.txt', 'a')
            data_id.write('Vector of coefficients:')
            for i in range(0, len(coeff)):
                if i < len(coeff) - 1:
                    data_id.write(' %.8f,' % coeff[i])
                else:
                    data_id.write(' %.8f\n' % coeff[i])

            data_id.write('gradmag: %.8f.\n' % gradmag[step])

            norm_diffY = 0
            for i in range(0, len(var)):
                norm_diffY = norm_diffY + (Y[step][i] - Y[step - 1][i]) ** 2
            new_S = (((mt.sqrt(gradmag[step])) / (gradmag[step - 1])) ** M) * (mt.sqrt(norm_diffY))
            if new_S > SMAX:
                new_S = SMAX
            S.append(new_S)
            data_id.write('Step size value (S): %.8f.\n' % S[step])
            data_id.close()
            new_var = []

            for i in range(0, len(var)):
                new_dv = Y[step][i] + S0 * coeff[i + 1] / gradmag[step]
                # Check limits (varbound) for new optimal design variables

                if new_dv <= lb[i]:
                    new_dv = lb[i]
                elif new_dv >= ub[i]:
                    new_dv = ub[i]
                else:
                    pass
                new_var.append(new_dv)
            Y.append(new_var)
        else:
            check = check + 1
            gradmag.append(gradmag[step-1])
            S.append(S[step-1])
            Y.append(var)

        # ======================================================================================= CONVERGENCE EVALUATION
        if check == 0:
            if abs(opt[step] - opt[step - 1]) <= tolerance:
                counter = counter + 1
            else:
                counter = 0
        else:
            counter = counter + 1
        data_id = open('HistorySTEEPEST.txt', 'a')
        data_id.write('Counter: %d.\n' % counter)
        data_id.close()


    print('\n\nOptimization ended!\n\nStep required: %d.\nStall iterations: %d.\n' % (step, counter))
    print('Optimum Fitness: %.8f.\n' % opt[step])
    print('Optimal Design variables: ')
    for i in range(0, len(var)):
        if i < len(var) - 1:
            print('%.8f, ' % Y[step][i])
        else:
            print('%.8f.\n' % Y[step][i])

    return Y[step], opt[len(opt)-1]


def opt_method_steepest(flow, n, objective_function, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, bounds_alpha, bounds_dist, bounds_crel, bounds_params, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, dev_std, iter_range, farfield_size, varbound, preliminary_method):

    S0, SMAX, REF_SIZE, min_iter, max_iter, max_stall_iterations, tolerance, debug, noise, processes = main_STEEPEST_algo_params()

    if S0 == 'DEFAULT':
        S0 = 0.07
    if SMAX == 'DEFAULT':
        SMAX = 0.05
    if REF_SIZE == 'DEFAULT':
        REF_SIZE = 0.06
    if min_iter == 'DEFAULT':
        min_iter = 5
    if max_iter == 'DEFAULT':
        max_iter = 25
    if max_stall_iterations == 'DEFAULT':
        max_stall_iterations = 5
    if tolerance == 'DEFAULT':
        tolerance = 0.01
    if debug == 'DEFAULT':
        debug = False
    if noise == 'DEFAULT':
        noise = 0.017
    if processes == 'DEFAULT':
        processes = 1

    data_id = open('Input_PSO.txt', 'w+')
    data_id.write(
        'S0: %d.\nSMAX: %.5f.\nREF_SIZE: %.5f.\nmin_iter: %.5f.\nmax_iter: %d.\nmax_stall_iterations: %.10f.\ntolerance: %.10f.\nprocesses: %d\n.debug: %s.\nnoise: %.8f.\n' % (
            S0, SMAX, REF_SIZE, min_iter, max_iter, max_stall_iterations, tolerance, processes, str(debug), noise))

    lb = []
    ub = []
    for i in range(0, len(varbound)):
        lb.append(varbound[i][0])
        ub.append(varbound[i][1])

    data_id.write('Lower bounds: ')
    for i in range(0, len(lb)):
        if i < len(lb) - 1:
            data_id.write('%.5f, ' % lb[i])
        else:
            data_id.write('%.5f.\n' % lb[i])

    data_id.write('Upper bounds: ')
    for i in range(0, len(ub)):
        if i < len(ub) - 1:
            data_id.write('%.5f, ' % ub[i])
        else:
            data_id.write('%.5f.\n' % ub[i])
    data_id.close()
    lb = (np.asarray(lb)).tolist()
    ub = (np.asarray(ub)).tolist()

    args = (flow, n, objective_function, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, bounds_alpha, bounds_dist, bounds_crel, bounds_params, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, dev_std, iter_range, farfield_size, varbound, preliminary_method)

    xopt, fopt = steepest(obj_steepest, lb, ub, args=args, S0=S0, SMAX=SMAX, REF_SIZE=REF_SIZE, min_iter=min_iter,
                          max_iter=max_iter, max_stall_iterations=max_stall_iterations, tolerance=tolerance,
                          debug=debug, noise=noise, processes=processes)

    print('The optimum is at:')
    print('    {}'.format(xopt))
    print('Optimal function values:')
    print('    Optimal Fitness         : {}'.format(fopt))

    return []


def obj_steepest(x, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, id, processes, farfield_size, preliminary_method):
    if centroid == 0:
        path = ('./STEP_%d/Centroid_%d' % (step, step))
    elif type(step) != int:
        flow = preliminary_method[0]
        path = ('./Preliminary_study/Process_%d' % id)
    else:
        path = ('./STEP_%d/Process_%d' % (step, id))
    if not os.path.exists(path):
        os.makedirs(path)
    nairfoils = len(typ)
    for i in range(0, len(typ)):
        if typ[i] == ('MY_FILE_%d' % (i + 1)):
            shutil.copy(('MY_FILE_%d.dat' % (i + 1)), path)
    shutil.copy('cfd_config_settings.cfg', path)
    shutil.copy('CFD_run.sh', path)
    shutil.copy('Geo2.sh', path)
    shutil.copy('mesh_gen.py', path)
    shutil.copy('wing_launch_opt.py', path)
    shutil.copy('multiGeometry.py', path)
    shutil.copy('airfoilShape.py', path)
    shutil.copy('camberline.py', path)
    shutil.copy('cfg_printing.py', path)
    shutil.copy('getThickParamIGP.py', path)
    shutil.copy('input_check_opt.py', path)
    shutil.copy('lift_driver_mode.py', path)
    if type(step) != int:
        shutil.copy('main_configuration_file_preliminary.py', path)
    else:
        shutil.copy('main_configuration_file.py', path)
    shutil.copy('pts_gen.py', path)
    shutil.copy('wall_spacing.py', path)
    # with open('readme.txt') as f:
    #     old_N = f.readlines()
    #
    # dummy_id.write(N)
    alpha = [None] * len(start_alpha)
    dist = [None] * len(start_dist)
    crel = [None] * len(start_crel)
    params = [None] * len(start_params)

    dist[0] = [0, 0]
    crel[0] = 1
    s = 0

    if centroid == 0:
        targ = x_centr
    else:
        targ = x[id]

    for i in range(0, len(design_variables_alpha)):
        if design_variables_alpha[i] == 'Y':
            alpha[i] = targ[s]
            s = s + 1
        else:
            alpha[i] = start_alpha[i]

    for i in range(0, len(design_variables_dist)):
        dist[i + 1] = [None, None]
        for j in range(0, len(design_variables_dist[i])):
            if design_variables_dist[i][j] == 'Y':
                dist[i + 1][j] = targ[s]
                s = s + 1
            else:
                dist[i + 1][j] = start_dist[i + 1][j]

    for i in range(0, len(design_variables_crel)):
        if design_variables_crel[i] == 'Y':
            crel[i + 1] = targ[s]
            s = s + 1
        else:
            crel[i + 1] = start_crel[i + 1]

    for i in range(0, len(design_variables_params)):
        if typ[i] == "IGP":
            reference = len(design_variables_params[i])
        else:
            reference = len(start_params[i])
        params[i] = [None] * reference
        for j in range(0, reference):
            if design_variables_params[i][j] == 'Y':
                params[i][j] = targ[s]
                s = s + 1
            else:
                params[i][j] = start_params[i][j]

    os.chdir(path)

    wing_launch_opt(flow, n, params, alpha, dist, crel, typ, TE, Re, mu, nodes, y_plus, thick, progr, temp,
                           ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr,
                           semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining,
                           ref_airfoil, farfield_size)
    if type(step) != int:
        VAR_PREL = [['KIND_TURB_MODEL', KIND_TURB_MODEL_PREL], ['KIND_TRANS_MODEL', KIND_TRANS_MODEL_PREL],
                    ['FREESTREAM_TURBULENCEINTENSITY', FREESTREAM_TURBULENCEINTENSITY_PREL],
                    ['RESTART_SOL', RESTART_SOL_PREL],
                    ['MACH_NUMBER', Mach], ['AOA', alpha[0]], ['SIDESLIP_ANGLE', SIDESLIP_ANGLE_PREL],
                    ['FREESTREAM_TEMPERATURE', temp], ['GAS_CONSTANT', GAS_CONSTANT_PREL],
                    ['FLUID_MODEL', FLUID_MODEL_PREL], ['GAMMA_VALUE', GAMMA_VALUE_PREL], ['REYNOLDS_NUMBER', Re],
                    ['REYNOLDS_LENGTH', REYNOLDS_LENGTH_PREL], ['VISCOSITY_MODEL', VISCOSITY_MODEL_PREL],
                    ['MU_CONSTANT', mu],
                    ['MU_T_REF', MU_T_REF_PREL], ['SUTHERLAND_CONSTANT', SUTHERLAND_CONSTANT_PREL],
                    ['CONDUCTIVITY_MODEL', CONDUCTIVITY_MODEL_PREL], ['PRANDTL_LAM', PRANDTL_LAM_PREL],
                    ['PRANDTL_TURB', PRANDTL_TURB_PREL],
                    ['REF_ORIGIN_MOMENT_X', REF_ORIGIN_MOMENT_X_PREL],
                    ['REF_ORIGIN_MOMENT_Y', REF_ORIGIN_MOMENT_Y_PREL],
                    ['REF_ORIGIN_MOMENT_Z', REF_ORIGIN_MOMENT_Z_PREL], ['REF_LENGTH', REF_LENGTH_PREL],
                    ['REF_AREA', REF_AREA_PREL],
                    ['CFL_NUMBER', CFL_NUMBER], ['CFL_ADAPT', CFL_ADAPT_PREL],
                    ['CFL_ADAPT_PARAM', CFL_ADAPT_PARAM_PREL], ['ITER', ITER_PREL],
                    ['CONV_NUM_METHOD_FLOW', CONV_NUM_METHOD_FLOW_PREL], ['MUSCL_FLOW', MUSCL_FLOW_PREL],
                    ['SLOPE_LIMITER_FLOW', SLOPE_LIMITER_FLOW_PREL],
                    ['VENKAT_LIMITER_COEFF', VENKAT_LIMITER_COEFF_PREL],
                    ['JST_SENSOR_COEFF', JST_SENSOR_COEFF_PREL], ['CONV_FIELD', CONV_FIELD_PREL],
                    ['CONV_RESIDUAL_MINVAL', CONV_RESIDUAL_MINVAL_PREL], ['CONV_STARTITER', CONV_STARTITER_PREL],
                    ['CONV_CAUCHY_ELEMS', CONV_CAUCHY_ELEMS_PREL], ['CONV_CAUCHY_EPS', CONV_CAUCHY_EPS_PREL],
                    ['MESH_FILENAME', 'Test.su2'], ['SCREEN_OUTPUT', SCREEN_OUTPUT_PREL],
                    ['HISTORY_OUTPUT', HISTORY_OUTPUT_PREL],
                    ['OUTPUT_FILES', OUTPUT_FILES_PREL], ['TABULAR_FORMAT', TABULAR_FORMAT_PREL],
                    ['SCREEN_WRT_FREQ_INNER', SCREEN_WRT_FREQ_INNER_PREL], ['OUTPUT_WRT_FREQ', OUTPUT_WRT_FREQ_PREL]]

        VAR2_PREL = [['FIXED_CL_MODE', FIXED_CL_MODE_PREL], ['TARGET_CL', TARGET_CL_PREL],
                     ['DCL_DALPHA', DCL_DALPHA_PREL],
                     ['UPDATE_AOA_ITER_LIMIT', UPDATE_AOA_ITER_LIMIT_PREL], ['ITER_DCL_DALPHA', ITER_DCL_DALPHA_PREL],
                     ['EVAL_DOF_DCX', EVAL_DOF_DCX_PREL]]

        cfg_printing(nairfoils, VAR_PREL, VAR2_PREL, flow) #, id)
    else:
        VAR = [['KIND_TURB_MODEL', KIND_TURB_MODEL], ['KIND_TRANS_MODEL', KIND_TRANS_MODEL],
               ['FREESTREAM_TURBULENCEINTENSITY', FREESTREAM_TURBULENCEINTENSITY], ['RESTART_SOL', RESTART_SOL],
               ['MACH_NUMBER', Mach], ['AOA', alpha[0]], ['SIDESLIP_ANGLE', SIDESLIP_ANGLE],
               ['FREESTREAM_TEMPERATURE', temp], ['GAS_CONSTANT', GAS_CONSTANT],
               ['FLUID_MODEL', FLUID_MODEL], ['GAMMA_VALUE', GAMMA_VALUE], ['REYNOLDS_NUMBER', Re],
               ['REYNOLDS_LENGTH', REYNOLDS_LENGTH], ['VISCOSITY_MODEL', VISCOSITY_MODEL], ['MU_CONSTANT', mu],
               ['MU_T_REF', MU_T_REF], ['SUTHERLAND_CONSTANT', SUTHERLAND_CONSTANT],
               ['CONDUCTIVITY_MODEL', CONDUCTIVITY_MODEL], ['PRANDTL_LAM', PRANDTL_LAM], ['PRANDTL_TURB', PRANDTL_TURB],
               ['REF_ORIGIN_MOMENT_X', REF_ORIGIN_MOMENT_X], ['REF_ORIGIN_MOMENT_Y', REF_ORIGIN_MOMENT_Y],
               ['REF_ORIGIN_MOMENT_Z', REF_ORIGIN_MOMENT_Z], ['REF_LENGTH', REF_LENGTH], ['REF_AREA', REF_AREA],
               ['CFL_NUMBER', CFL_NUMBER], ['CFL_ADAPT', CFL_ADAPT], ['CFL_ADAPT_PARAM', CFL_ADAPT_PARAM],
               ['ITER', ITER],
               ['CONV_NUM_METHOD_FLOW', CONV_NUM_METHOD_FLOW], ['MUSCL_FLOW', MUSCL_FLOW],
               ['SLOPE_LIMITER_FLOW', SLOPE_LIMITER_FLOW], ['VENKAT_LIMITER_COEFF', VENKAT_LIMITER_COEFF],
               ['JST_SENSOR_COEFF', JST_SENSOR_COEFF], ['CONV_FIELD', CONV_FIELD],
               ['CONV_RESIDUAL_MINVAL', CONV_RESIDUAL_MINVAL], ['CONV_STARTITER', CONV_STARTITER],
               ['CONV_CAUCHY_ELEMS', CONV_CAUCHY_ELEMS], ['CONV_CAUCHY_EPS', CONV_CAUCHY_EPS],
               ['MESH_FILENAME', 'Test.su2'], ['SCREEN_OUTPUT', SCREEN_OUTPUT], ['HISTORY_OUTPUT', HISTORY_OUTPUT],
               ['OUTPUT_FILES', OUTPUT_FILES], ['TABULAR_FORMAT', TABULAR_FORMAT],
               ['SCREEN_WRT_FREQ_INNER', SCREEN_WRT_FREQ_INNER], ['OUTPUT_WRT_FREQ', OUTPUT_WRT_FREQ]]

        VAR2 = [['FIXED_CL_MODE', FIXED_CL_MODE], ['TARGET_CL', TARGET_CL], ['DCL_DALPHA', DCL_DALPHA],
                ['UPDATE_AOA_ITER_LIMIT', UPDATE_AOA_ITER_LIMIT], ['ITER_DCL_DALPHA', ITER_DCL_DALPHA],
                ['EVAL_DOF_DCX', EVAL_DOF_DCX]]

        cfg_printing(nairfoils, VAR, VAR2, flow) #, step)

    subp = subprocess.call("./CFD_run.sh")

    path_parent = os.path.dirname(os.path.dirname(os.getcwd()))
    os.chdir(path_parent)

    return []
