import os
from main_preliminary_study import BB
from main_preliminary_study import LHS
from pyDOE import *
from scipy.stats.distributions import norm
import pandas as pd
from STEEPEST import obj_steepest
import multiprocessing as mp
from Panel_Method.PanelMethod import HS_panelmethod
import math as mt
from main_preliminary_study import HS


def preliminary_study(preliminary_method, flow, n, objective_function, optim_method, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, bounds_alpha, bounds_dist, bounds_crel, bounds_params, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, dev_std, iter_range, farfield_size, varbound):
    N = 0
    for i in range(0, len(design_variables_alpha)):
        if design_variables_alpha[i] == 'Y':
            N = N + 1
    for i in range(0, len(design_variables_dist)):
        for j in range(0, len(design_variables_dist[i])):
            if design_variables_dist[i][j] == 'Y':
                N = N + 1
    for i in range(0, len(design_variables_crel)):
        if design_variables_crel[i] == 'Y':
            N = N + 1
    for i in range(0, len(design_variables_params)):
        for j in range(0, len(design_variables_params[i])):
            if design_variables_params[i][j] == 'Y':
                N = N + 1

    if preliminary_method[1] == 'BB':
        if N < 3:
            print('Box-Behnken (BB) applies only to problems with at least 3 design variables.\n')
            import sys
            sys.exit()
        centre, size, processes, bounds_margin = BB()
        design_old = bbdesign(N, center=centre)
        design = [0] * len(design_old)
        for i in range(0, len(design)):
            design[i] = design_old[i] * size

    elif preliminary_method[1] == 'LHS':
        samples, criterion, stdvs, processes, bounds_margin = LHS()
        if samples == 'DEFAULT':
            samples = N
        if len(stdvs) != N:
            print('Error: standard deviation for preliminary candidates population "stdvs" must have the same length of total amount of design variables, defined by "Y" in main_opt (%d).\nCheck item "stdvs".\n' % N)
            import sys
            sys.exit()

        design = lhs(N, samples=samples)

        means = [None] * N
        k = 0
        for i in range(0, len(design_variables_alpha)):
            if design_variables_alpha[i] == 'Y':
                means[k] = start_alpha[i]
                k = k + 1

        for i in range(0, len(design_variables_dist)):
            for j in range(0, len(design_variables_dist[i])):
                if design_variables_dist[i][j] == 'Y':
                    means[k] = start_dist[i - 1][j]
                    k = k + 1

        for i in range(0, len(design_variables_crel)):
            if design_variables_crel[i] == 'Y':
                means[k] = start_crel[i + 1]
                k = k + 1

        for i in range(0, len(typ)):
            for j in range(0, len(design_variables_params[i])):
                if design_variables_params[i][j] == 'Y':
                    means[k] = start_params[i][j]
                    k = k + 1

        for i in range(0, N):
            design[:, i] = norm(loc=means[i], scale=stdvs[i]).ppf(design[:, i])

    design = design.tolist()

    data_id = open('Preliminary_study.txt', 'w+')
    data_id.write('Preliminary study: design variables of each experiment and respective fitness.\n\n')
    for i in range(0, len(design)):
        data_id.write('Process ' + str(i) + ' design variables: ')

        for j in range(0, len(design[i])):
            if design[i][j] < varbound[j][0]:
                design[i][j] = varbound[j][0]
            if design[i][j] > varbound[j][1]:
                design[i][j] = varbound[j][1]
            if j <= len(design[i]) - 2:
                data_id.write('%.8f, ' % design[i][j])
            else:
                data_id.write('%.8f.\n' % design[i][j])

    data_id.close()

    if preliminary_method[0] == 'HS':
        import shutil
        shutil.copy('multiGeometry.py', './Panel_Method')
        shutil.copy('airfoilShape.py', './Panel_Method')
        shutil.copy('camberline.py', './Panel_Method')
        shutil.copy('getThickParamIGP.py', './Panel_Method')
        os.chdir('./Panel_Method')

        # Hess-Smith Panel method
        alpha_opt_preliminary, crel_opt_preliminary, dist_opt_preliminary, params_opt_preliminary, ub, lb, OBJ, bounds = HS_panelmethod(n, start_alpha, start_dist, start_crel, start_params, design, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, ref_airfoil, typ, TE, objective_function, bounds_margin, varbound)

        path_parent = os.path.dirname(os.getcwd())
        os.chdir(path_parent)

        data_id = open('Preliminary_study.txt', 'a')
        for i in range(0, len(design)):
            data_id.write('Process ' + str(i) + ' fitness: ' + str(OBJ[i]) + '.\n')
        data_id.close()

        bounds = [None] * len(lb)
        for i in range(0, len(bounds)):
            bounds[i] = [None, None]
            bounds[i][0] = lb[i]
            bounds[i][1] = ub[i]
            if bounds[i][0] < varbound[i][0]:
                bounds[i][0] = varbound[i][0]
            if bounds[i][1] > varbound[i][1]:
                bounds[i][1] = varbound[i][1]

    else:
        # Calculate objective and extract it from csv file
        PROC = []

        step = 'Preliminary'
        centroid = 1
        opt = []
        x_centr = []

        if processes > 1:
            if processes > len(design):
                processes = len(design)
                data_id = open('Preliminary_study.txt', 'a')
                data_id.write('Invalid definition for number of processes: maximum number is equal to [(n° of design variables) + 1].\nAs consequence, number of processes is reduced to %d.\n' % processes)
                data_id.close()
            i = 0
            while i <= len(design) - 1:
                for j in range(i, min(processes + i, len(design))):
                    p = mp.Process(target=obj_steepest, args=(design, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, j, processes, farfield_size, preliminary_method))
                    p.start()
                    PROC.append(p)
                for proc in PROC:
                    proc.join()
                i = i + processes
        else:
            processes = 1
            for i in range(0, len(design)):
                obj_steepest(design, x_centr, iter_range, dev_std, opt, flow, objective_function, n, typ, design_variables_alpha, design_variables_dist, design_variables_crel, design_variables_params, TE, start_dist, start_alpha, start_crel, start_params, varbound, Re, mu, nodes, y_plus, thick, progr, temp, ellipse_dimension, Mach, Mesh_Algo, external_pts, wake_length, wake_progr, semicircle_dimension, semicircle_elem_factor, wall_refining, ellipse_refining, ref_airfoil, limit_exclusions, step, centroid, i, processes, farfield_size, preliminary_method)

        obj = np.zeros(len(design))
        for i in range(0, len(design)):
            path = ('./Preliminary_study/Process_%d' % i)
            os.chdir(path)

            try:
                path2 = ("history.csv")
                df = pd.read_csv(path2)
                if objective_function[1] == 'LIFT':
                    column_name = '       "CL"       '
                elif objective_function[1] == 'DRAG':
                    column_name = '       "CD"       '
                else:
                    column_name = '      "CEff"      '

                obj_old = df.at[(df.index.stop - 1), column_name]
                sim_iter = df.index.stop - 1
                if sim_iter <= iter_range:
                    iter_range = sim_iter
                sum_mean = 0
                for j in range(sim_iter - iter_range, sim_iter):
                    sum_mean = sum_mean + df.at[j, column_name]
                mean_obj = sum_mean / iter_range

                sum_dev_std = 0
                for j in range(sim_iter - iter_range, sim_iter):
                    sum_dev_std = sum_dev_std + ((df.at[j, column_name] - mean_obj) ** 2)
                sigma = mt.sqrt(sum_dev_std / iter_range)

                obj[i] = obj_old
                if limit_exclusions[0] == 'YES' and sigma > dev_std:
                    obj[i] = 0
            except:
                obj[i] = 0

            path_parent = os.path.dirname(os.path.dirname(os.getcwd()))
            os.chdir(path_parent)

            data_id = open('Preliminary_study.txt', 'a')
            data_id.write('Process ' + str(i) + ' Fitness: %.8f.\n' % obj[i])
            data_id.close()

        if objective_function[0] == 'MAX':
            opt_index = np.argmax(obj)
            opt = np.max(obj)
        else:
            opt_index = np.argmin(obj)
            opt = np.min(obj)

        opt_var = design[opt_index]

        data_id = open('Preliminary_study.txt', 'a')
        data_id.write('Optimal Process from preliminary study: %d.\n' % opt_index)
        data_id.write('Optimal Fitness obtained from preliminary study: %.8f.\n' % opt)
        data_id.write('Optimal Variable obtained from preliminary study: ')
        for k in range(0, len(opt_var)):
            if k < len(opt_var) - 1:
                data_id.write('%.8f, ' % opt_var[k])
            else:
                data_id.write('%.8f.\n' % opt_var[k])

        # Design variables
        bounds_var = []
        # Bounds definition
        for i in range(0, len(obj)):
            if abs(opt - obj[i]) <= bounds_margin:
                bounds_var = bounds_var + [design[i]]


        # Results gathering
        alpha_opt_preliminary = [None] * len(typ)
        dist_opt_preliminary = [None] * len(typ)
        crel_opt_preliminary = [None] * len(typ)
        params_opt_preliminary = [None] * len(typ)

        k = 0
        for i in range(0, len(design_variables_alpha)):
            if design_variables_alpha[i] == 'Y':
                alpha_opt_preliminary[i] = opt_var[k]
                k = k + 1
            else:
                alpha_opt_preliminary[i] = start_alpha[i]

        dist_opt_preliminary[0] = [0, 0]

        for i in range(1, len(start_dist)):
            dist_opt_preliminary[i] = [None, None]
            for j in range(0, 2):
                if design_variables_dist[i-1][j] == 'Y':
                    dist_opt_preliminary[i][j] = opt_var[k]
                    k = k + 1
                else:
                    dist_opt_preliminary[i][j] = start_dist[i][j]

        crel_opt_preliminary[0] = 1
        for i in range(1, len(start_crel)):
            if design_variables_crel[i-1] == 'Y':
                crel_opt_preliminary[i] = opt_var[k]
                k = k + 1
            else:
                crel_opt_preliminary[i] = start_crel[i]

        for i in range(0, len(start_params)):
            if ('Y' in design_variables_params[i]):
                params_opt_preliminary[i] = [None] * len(design_variables_params[i])
                for j in range(0, len(design_variables_params[i])):
                    params_opt_preliminary[i][j] = opt_var[k]
                    k = k + 1
            else:
                params_opt_preliminary[i] = start_params[i]

        bounds = [None] * N

        for i in range(0, len(bounds)):
            dummy = []
            for j in range(0, len(bounds_var)):
                dummy.append(bounds_var[j][i])
            bounds[i] = [None, None]
            bounds[i][0] = min(dummy)
            if bounds[i][0] < varbound[i][0]:
                bounds[i][0] = varbound[i][0]
            bounds[i][1] = max(dummy)
            if bounds[i][1] > varbound[i][1]:
                bounds[i][1] = varbound[i][1]

    data_id = open('Preliminary_study.txt', 'a')
    data_id.write('New configuration obtained from preliminary study: \n')

    data_id.write('     Angles of attack: [%.8f, ' % alpha_opt_preliminary[0])
    for k in range(1, len(alpha_opt_preliminary)):
        if k < len(alpha_opt_preliminary) - 1:
            data_id.write('%.8f, ' % alpha_opt_preliminary[k])
        else:
            data_id.write('%.8f].\n' % alpha_opt_preliminary[k])

    data_id.write('     Relative distances: ')
    for k in range(1, len(dist_opt_preliminary)):
        if k < len(dist_opt_preliminary) - 1:
            data_id.write('[%.8f, %.8f], ' % (dist_opt_preliminary[k][0], dist_opt_preliminary[k][1]))
        else:
            data_id.write('[%.8f, %.8f].\n' % (dist_opt_preliminary[k][0], dist_opt_preliminary[k][1]))

    data_id.write('     Chords: 1, ')
    for k in range(1, len(crel_opt_preliminary)):
        if k < len(crel_opt_preliminary) - 1:
            data_id.write('%.8f, ' % crel_opt_preliminary[k])
        else:
            data_id.write('%.8f.\n' % crel_opt_preliminary[k])

    data_id.write('     Shape Parameters: ')
    for k in range(0, len(params_opt_preliminary)):
        if (typ[k] == 'MY_FILE_%d' % (k + 1)):
            data_id.write('[MY_FILE_%d] ' % (k+1))
        else:
            data_id.write('[%.8f, ' % params_opt_preliminary[k][0])
            for p in range(1, len(params_opt_preliminary[k])):
                if p < len(params_opt_preliminary[k]) - 1:
                    data_id.write('%.8f, ' % params_opt_preliminary[k][p])
                else:
                    data_id.write('%.8f]. ' % params_opt_preliminary[k][p])

    data_id.write('\nNew Bounds obtained from preliminary study: ')
    for k in range(0, len(bounds)):
        if k < len(bounds) - 1:
            data_id.write('[%.8f, %.8f], ' % (bounds[k][0], bounds[k][1]))
        else:
            data_id.write('[%.8f, %.8f].\n' % (bounds[k][0], bounds[k][1]))

    data_id.close()

    return alpha_opt_preliminary, dist_opt_preliminary, crel_opt_preliminary, params_opt_preliminary, bounds
