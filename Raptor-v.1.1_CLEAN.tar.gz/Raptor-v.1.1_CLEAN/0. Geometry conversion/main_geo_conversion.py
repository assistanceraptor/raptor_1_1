from geo_converter import geo_converter

input_filename = 'MY_FILE_2'
output_filename = 'MY_FILE_2.dat'

rotation = 'YES'
scaling = 'YES'
# ======================================
geo_converter(input_filename, output_filename, rotation, scaling)
